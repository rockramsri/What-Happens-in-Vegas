import SwiftUI
import Combine
import CoreImage.CIFilterBuiltins
import UIKit  // Import UIKit for UIImage support
import ContactsUI  // Import Contacts framework
import Firebase

@main
struct TripPlannerApp: App {
    init() {
        if FirebaseApp.app() == nil {
            FirebaseApp.configure()
        }
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
