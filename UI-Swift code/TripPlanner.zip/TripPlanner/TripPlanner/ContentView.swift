import SwiftUI
import Combine
import CoreImage.CIFilterBuiltins
import UIKit  // Import UIKit for UIImage support
import ContactsUI  // Import Contacts framework

struct TripGroup: Identifiable {
    let id: UUID
    var name: String
    var members: [String] = []
    var qrImage: UIImage? // Store the QR code image
    
    init(id: UUID = UUID(), name: String, members: [String] = [], qrImage: UIImage? = nil) {
        self.id = id
        self.name = name
        self.members = members
        self.qrImage = qrImage
    }
}

struct ContentView: View {
    @State private var groupName: String = ""
    @State private var groups: [TripGroup] = []
    @State private var editingIndex: Int? = nil
    
    var body: some View {
        NavigationView {
            VStack {
                TextField("Enter Group Name", text: $groupName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                Button(editingIndex == nil ? "Create Group" : "Update Group") {
                    if let index = editingIndex {
                        groups[index].name = groupName
                        editingIndex = nil
                    } else {
                        createGroup(name: groupName)
                    }
                    groupName = ""
                }
                .padding()
                
                List {
                    ForEach(groups.indices, id: \ .self) { index in
                        HStack {
                            NavigationLink(destination: ChatView(group: $groups[index])) {
                                Text(groups[index].name)
                            }
                            Spacer()
                            Button(action: {
                                editGroup(index)
                            }) {
                                Image(systemName: "pencil")
                            }
                            .buttonStyle(BorderlessButtonStyle())
                            
                            Button(action: {
                                deleteGroup(at: IndexSet(integer: index))
                            }) {
                                Image(systemName: "trash")
                            }
                            .buttonStyle(BorderlessButtonStyle())
                        }
                    }
                    .onDelete(perform: deleteGroup)
                }
            }
            .navigationTitle("Trip Builder")
        }
    }
    
    private func deleteGroup(at offsets: IndexSet) {
        groups.remove(atOffsets: offsets)
    }
    
    private func editGroup(_ index: Int) {
        groupName = groups[index].name
        editingIndex = index
    }
    
    private func createGroup(name: String) {
        let url = URL(string: "http://127.0.0.1:5001/generate_qr")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let json: [String: Any] = ["group_name": name]
        let jsonData = try! JSONSerialization.data(withJSONObject: json, options: [])
        request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let data = data, let qrImage = UIImage(data: data) {
                DispatchQueue.main.async {
                    let newGroup = TripGroup(name: name, qrImage: qrImage)
                    groups.append(newGroup)
                }
            } else {
                print("Failed to fetch QR code: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
        task.resume()
    }
}

struct ChatView: View {
    @Binding var group: TripGroup
    @State private var message: String = ""
    @State private var messages: [(String, String)] = [] // (Sender, Message)
    @State private var showMembers = false
    @State private var showQR = false
    @State private var showCardView = false
    @State private var showLocationView = false // New state for locations

    var body: some View {
        VStack {
            List(messages, id: \.1) { sender, msg in
                HStack(alignment: .top) {
                    VStack(alignment: .leading) {
                        Text(sender)
                            .font(.caption)
                            .foregroundColor(.gray)
                        Text(msg)
                            .padding(10)
                            .background(Color.blue.opacity(0.2))
                            .cornerRadius(10)
                    }
                    Spacer()
                }
                .padding(.vertical, 2)
            }

            HStack {
                TextField("Enter message", text: $message)
                    .textFieldStyle(RoundedBorderTextFieldStyle())

                Button("Send") {
                    sendMessage()
                }
            }
            .padding()

            Button("View Members") {
                showMembers = true
            }
            .padding()
        }
        .navigationTitle(group.name)
        .navigationBarItems(trailing: HStack {
            Button(action: {
                showQR = true
            }) {
                Image(systemName: "qrcode.viewfinder")
            }
            Button(action: {
                showCardView = true
            }) {
                Image(systemName: "creditcard.fill")
            }
            Button(action: { // New button for location links
                showLocationView = true
            }) {
                Image(systemName: "map.fill") // Map icon 🗺️
            }
        })
        .sheet(isPresented: $showQR) {
            QRCodeView(qrImage: group.qrImage)
        }
        .sheet(isPresented: $showMembers) {
            GroupMembersView(group: $group)
        }
        .sheet(isPresented: $showCardView) {
            CardView()
        }
        .sheet(isPresented: $showLocationView) { // Opens the new location view
            LocationView()
        }
    }
    
    private func sendMessage() {
        let sender = group.members.isEmpty ? "You" : group.members.first!
        messages.append((sender, message))
        
        if message.lowercased().contains("@trip_planner") {
            sendAIResponse()
        }
        
        message = ""
    }
    
    private func sendAIResponse() {
        let url = URL(string: "http://127.0.0.1:5001/ai_response")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let json: [String: Any] = ["message": message]
        let jsonData = try! JSONSerialization.data(withJSONObject: json, options: [])
        request.httpBody = jsonData
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let data = data {
                if let responseDict = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: String],
                   let aiResponse = responseDict["response"] {
                    DispatchQueue.main.async {
                        self.messages.append(("@trip_planner", aiResponse))
                    }
                }
            } else {
                print("Failed to fetch AI response: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
        task.resume()
    }
}

struct CardView: View {
    @State private var hotelData: [String: [String: String]] = [:]
    
    var body: some View {
        ScrollView {
            VStack(spacing: 15) {
                ForEach(hotelData.keys.sorted(), id: \.self) { hotel in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(hotel)
                            .font(.headline)
                            .bold()
                        ForEach(hotelData[hotel]!.keys.sorted(), id: \.self) { key in
                            Text("\(key.capitalized): \(hotelData[hotel]![key]!)")
                                .font(.subheadline)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                    .shadow(radius: 2)
                }
            }
            .padding()
        }
        .onAppear {
            fetchHotelData()
        }
    }
    
    private func fetchHotelData() {
        guard let url = URL(string: "http://127.0.0.1:5001/get_hotels") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, _, error in
            if let data = data {
                if let responseDict = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: [String: String]] {
                    DispatchQueue.main.async {
                        self.hotelData = responseDict
                    }
                }
            } else {
                print("Error fetching hotel data: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
        task.resume()
    }
}

struct LocationView: View {
    @State private var locationData: [String: [String: String]] = [:]

    var body: some View {
        ScrollView {
            VStack(spacing: 15) {
                ForEach(locationData.keys.sorted(), id: \.self) { location in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(location)
                            .font(.headline)
                            .bold()
                        if let link = locationData[location]?["link"] {
                            Link("View Location", destination: URL(string: link)!)
                                .foregroundColor(.blue)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                    .shadow(radius: 2)
                }
            }
            .padding()
        }
        .onAppear {
            fetchLocationData()
        }
    }

    private func fetchLocationData() {
        guard let url = URL(string: "http://127.0.0.1:5001/get_locations") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, _, error in
            if let data = data {
                if let responseDict = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: [String: String]] {
                    DispatchQueue.main.async {
                        self.locationData = responseDict
                    }
                }
            } else {
                print("Error fetching location data: \(error?.localizedDescription ?? "Unknown error")")
            }
        }
        task.resume()
    }
}


struct QRCodeView: View {
    var qrImage: UIImage?
    
    var body: some View {
        VStack {
            if let image = qrImage {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200)
            } else {
                Text("No QR Code Available")
            }
        }
        .navigationTitle("Group QR Code")
    }
}

struct GroupMembersView: View {
    @Binding var group: TripGroup
    @State private var showContactPicker = false
    
    var body: some View {
        VStack {
            List {
                ForEach(group.members, id: \.self) { member in
                    HStack {
                        Text(member)
                        Spacer()
                        Button(action: {
                            removeMember(member)
                        }) {
                            Image(systemName: "minus.circle.fill")
                                .foregroundColor(.red)
                        }
                    }
                }
            }
            
            Button("Add People from Contacts") {
                showContactPicker = true
            }
            .padding()
        }
        .navigationTitle("Members of \(group.name)")
        .sheet(isPresented: $showContactPicker) {
            ContactPickerView { contact in
                group.members.append(contact)
            }
        }
    }
    
    private func removeMember(_ member: String) {
        group.members.removeAll { $0 == member }
    }
}

struct ContactPickerView: UIViewControllerRepresentable {
    var onSelectContact: (String) -> Void
    
    func makeUIViewController(context: Context) -> CNContactPickerViewController {
        let picker = CNContactPickerViewController()
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiViewController: CNContactPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        return Coordinator(onSelectContact: onSelectContact)
    }

    class Coordinator: NSObject, CNContactPickerDelegate {
        var onSelectContact: (String) -> Void
        
        init(onSelectContact: @escaping (String) -> Void) {
            self.onSelectContact = onSelectContact
        }
        
        func contactPicker(_ picker: CNContactPickerViewController, didSelect contact: CNContact) {
            let fullName = "\(contact.givenName) \(contact.familyName)"
            onSelectContact(fullName)
        }
    }
}
