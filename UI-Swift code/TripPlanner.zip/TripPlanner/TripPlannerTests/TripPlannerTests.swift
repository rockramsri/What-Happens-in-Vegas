//
//  TripPlannerTests.swift
//  TripPlannerTests
//
//  Created by Srikrishna Kumarasamy on 3/1/25.
//

import Testing

struct TripPlannerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
